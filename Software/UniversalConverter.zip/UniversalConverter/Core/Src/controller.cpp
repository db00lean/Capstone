/*
 * controller.cpp
 *
 *  Created on: Dec 1, 2021
 *      Author: davidboullie
 */

#include "controller.h"

uint8_t Controller::ReadButton(uint8_t btn_num) {
	uint8_t btn_state = -1;
	switch (btn_num) {
	case 1:
		btn_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12);
		break;
	case 2:
		btn_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_13);
		break;
	case 3:
		btn_state = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8);
		break;
	case 4:
		btn_state = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10);
		break;
	default:
		break;
	}
	return btn_state;
}

bool Controller::ButtonPress(uint8_t btn_num) {
	return ReadButton(btn_num) == 0;
}

void Controller::ToggleLED(void) {
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_9);
}

void Controller::start(void) {
	screen.Init();
	screen.StartScreen();

	v_in_1_read_mV = 0;
	i_in_1_read_mA = 0;
	v_in_2_read_mV = 0;
	i_in_2_read_mA = 0;
	v_out_read_mV = 0;
	i_out_read_mA = 0;
	v_out_sett_mV = 0;
	i_out_sett_mA = 0;
}

void Controller::startSettings(void) {
	screen.Clear();
	screen.SettingsSetup();
}

void Controller::runSettings(void) {
	uint8_t idx = 0;
	screen.SettingsUpdate(v_out_sett_mV, i_out_sett_mA, idx);
	while (not (idx == 2 && ButtonPress(3))) {
		if (ButtonPress(1)) {
			if (idx)
				idx -= 1;
			screen.SettingsUpdate(v_out_sett_mV, i_out_sett_mA, idx);
		}
		if (ButtonPress(2)) {
			if (idx == 0)
				v_out_sett_mV += 1000;
			if (idx == 1)
				i_out_sett_mA += 1;
			if (v_out_sett_mV > 55000)
				v_out_sett_mV = 55000;
			if (i_out_sett_mA > 6000)
				i_out_sett_mA = 6000;
			screen.SettingsUpdate(v_out_sett_mV, i_out_sett_mA, idx);
		}
		if (ButtonPress(3)) {
			if (idx == 0 && v_out_sett_mV)
				v_out_sett_mV -= 1000;
			if (idx == 1 && i_out_sett_mA)
				i_out_sett_mA -= 1;
			screen.SettingsUpdate(v_out_sett_mV, i_out_sett_mA, idx);
		}
		if (ButtonPress(4)) {
			idx += 1;
			if (idx > 2)
				idx = 2;
			screen.SettingsUpdate(v_out_sett_mV, i_out_sett_mA, idx);
		}
		HAL_Delay(100);
	}

}

void Controller::startMain(void) {
	screen.Clear();
	screen.MainSetup();
}

void Controller::runMain(void) {

	fetchReadings();
	screen.MainUpdate(v_in_1_read_mV, i_in_1_read_mA, v_in_1_read_mV >= 2500,
			v_in_2_read_mV, i_in_2_read_mA, v_in_2_read_mV >= 2500, v_out_read_mV,
			i_out_read_mA, v_out_read_mV >= 2.5);

}

void Controller::fetchReadings(void) {
	ADC_ChannelConfTypeDef sConfig = { 0 };
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_4CYCLES;

	//READ VIN 1
	sConfig.Channel = ADC_CHANNEL_2;
	HAL_ADC_ConfigChannel(&hadc, &sConfig);

	HAL_ADC_Start(&hadc); // start the adc
	HAL_ADC_PollForConversion(&hadc, 100); // poll for conversion
	uint16_t adc_val = HAL_ADC_GetValue(&hadc); // get the adc value
	HAL_ADC_Stop(&hadc); // stop adc
	v_in_1_read_mV = (adc_val * (3.3 / 4095) * 24.256) * 1000;
	HAL_Delay(5); // wait for 500ms


	//READ IIN 1
	sConfig.Channel = ADC_CHANNEL_1;
	HAL_ADC_ConfigChannel(&hadc, &sConfig);

	HAL_ADC_Start(&hadc); // start the adc
	HAL_ADC_PollForConversion(&hadc, 100); // poll for conversion
	 adc_val = HAL_ADC_GetValue(&hadc); // get the adc value
	HAL_ADC_Stop(&hadc); // stop adc
	i_in_1_read_mA = ((adc_val * (5 / 4095) / 60.0) /0.001)*1000;
	HAL_Delay(5); // wait for 500ms

	//Read VIN 2
	sConfig.Channel = ADC_CHANNEL_9;
	HAL_ADC_ConfigChannel(&hadc, &sConfig);

	HAL_ADC_Start(&hadc); // start the adc
	HAL_ADC_PollForConversion(&hadc, 100); // poll for conversion
	 adc_val = HAL_ADC_GetValue(&hadc); // get the adc value
	HAL_ADC_Stop(&hadc); // stop adc
	v_in_2_read_mV = (adc_val * (3.3 / 4095) * 24.256) * 1000;
	HAL_Delay(5); // wait for 500ms

	i_in_2_read_mA = 0;
	v_out_read_mV = v_out_sett_mV;
	i_out_read_mA = i_out_sett_mA;

}
