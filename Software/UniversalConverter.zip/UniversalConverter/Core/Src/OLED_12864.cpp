/*
 * OLED_12864.cpp
 *
 *  Created on: Nov 24, 2021
 *      Author: davidboullie
 */
#include "OLED_12864.h"


void OLED_12864::command(uint8_t code) {
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
	HAL_SPI_Transmit(&hspi1, (uint8_t *)&code, 1, 100);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
}

void OLED_12864::data(uint8_t d){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
	HAL_SPI_Transmit(&hspi1, (uint8_t *)&d, 1, 100);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
}


void OLED_12864::EnableGrayscaleTbl(void) {
	OLED_12864::command(0x00);
}

void OLED_12864::SetColAddr(uint8_t start, uint8_t end) {
	// max column value of 119d
	start %= 0x78;
	end %= 0x78;
	OLED_12864::command(0x15);
	OLED_12864::data(start);
	OLED_12864::data(end);
}

void OLED_12864::SetRowAddr(uint8_t start, uint8_t end) {
	// max row value of 127d
	start &= 0x7F;
	end &= 0x7F;
	OLED_12864::command(0x75);
	OLED_12864::data(start);
	OLED_12864::data(end);
}

void OLED_12864::SetWriteRAM(void) {
	OLED_12864::command(0x5C);
}

void OLED_12864::SetReadRAM(void) {
	OLED_12864::command(0x5D);
}

void OLED_12864::SetRemap(bool vert_addr_inc, bool col_addr_enab, bool nib_enab, bool COM_scan, bool COM_split, bool dual_COM) {
	uint8_t a = 0;
	uint8_t b = 1;

	a |= (uint8_t)vert_addr_inc << 0;
	a |= (uint8_t)col_addr_enab << 1;
	a |= (uint8_t)nib_enab << 2;
	a |= (uint8_t)COM_scan << 4;
	a |= (uint8_t)(COM_split && !dual_COM) << 5;

	b |= (uint8_t)dual_COM << 4;

	OLED_12864::command(0xA0);
	OLED_12864::data(a);
	OLED_12864::data(b);
}

void OLED_12864::SetDispStart(uint8_t start) {
	start &= 0x7F;

	OLED_12864::command(0xA1);
	OLED_12864::data(start);
}

void OLED_12864::SetDispOffset(uint8_t offset) {
	offset &= 0x7F;

	OLED_12864::command(0xA2);
	OLED_12864::data(offset);
}

void OLED_12864::DispMode(bool state, bool inverse) {
	uint8_t cmd = 0xA0;

	if(state) {
		if(inverse) {
			cmd += 7;
		} else {
			cmd += 6;
		}
	} else {
		cmd += 4;
	}

	OLED_12864::command(cmd);
}

void OLED_12864::PartialDisp(bool enable, uint8_t start_r, uint8_t end_r) {
	if(enable) {
		start_r %= 0x78;
		end_r %= 0x78;

		while(start_r >= end_r) {
			end_r += (start_r - end_r + 1);

			if(start_r >= 0x78) {
				start_r = 0x77;
				end_r = 0x78;
			}
		}

		OLED_12864::command(0xA8);
		OLED_12864::data(start_r);
		OLED_12864::data(end_r);
	} else {
		OLED_12864::command(0xA9);
	}
}

void OLED_12864::SetVDD(bool internal) {
	uint8_t a = 0;
	a += (uint8_t)internal;

	OLED_12864::command(0xAB);
	OLED_12864::data(a);
}

void OLED_12864::SetSleep(bool enable) {
	uint8_t cmd = 0xAE;
	cmd += (uint8_t)(!enable);

	OLED_12864::command(cmd);
}

void OLED_12864::SetPhase(uint8_t phase1, uint8_t phase2) {
	phase1 &= 0xF;
	phase2 &= 0xF;

	uint8_t a = (phase1 << 4) + phase2;

	OLED_12864::command(0xB1);
	OLED_12864::data(a);
}

void OLED_12864::SetClk_OscFreq(uint8_t clk_div, uint8_t osc_freq) {
	clk_div %= 0xB;
	osc_freq &= 0xF;

	uint8_t a = (clk_div << 4) + osc_freq;

	OLED_12864::command(0xB3);
	OLED_12864::data(a);
}

void OLED_12864::VSL_DispEnhance(bool internal_VSL, bool enhance) {
	uint8_t a = 0xA0;
	uint8_t b = 0xB5;

	a |= (uint8_t)internal_VSL << 1;

	b |= (uint8_t)enhance << 6;
	b |= (uint8_t)enhance << 3;

	OLED_12864::command(0xB4);
	OLED_12864::data(a);
	OLED_12864::data(b);
}

void OLED_12864::SetGPIO(bool gpio1_enab, bool gpio2_enab, bool gpio1_state, bool gpio2_state) {
	uint8_t gpio1, gpio2 = 0;

	if(gpio1_enab && gpio1_state) {
		gpio1 = 3;
	} else if (!gpio1_enab && gpio1_state) {
		gpio1 = 2;
	} else if (gpio1_enab && !gpio1_state) {
		gpio1 = 1;
	} else {
		gpio1 = 0;
	}

	if(gpio2_enab && gpio2_state) {
		gpio2 = 3;
	} else if (!gpio2_enab && gpio2_state) {
		gpio2 = 2;
	} else if (gpio2_enab && !gpio2_state) {
		gpio2 = 1;
	} else {
		gpio2 = 0;
	}

	uint8_t a = (gpio2 << 2) + gpio1;

	OLED_12864::command(0xB5);
	OLED_12864::data(a);
}

void OLED_12864::Set2ndPrecharge(uint8_t dclks) {
	dclks &= 0xF;
	OLED_12864::command(0xB6);
	OLED_12864::data(dclks);
}

void OLED_12864::SetGrayscaleTbl(uint8_t gs1, uint8_t gs2, uint8_t gs3, uint8_t gs4, uint8_t gs5, uint8_t gs6, uint8_t gs7, uint8_t gs8,
		uint8_t gs9, uint8_t gs10, uint8_t gs11, uint8_t gs12, uint8_t gs13, uint8_t gs14, uint8_t gs15) {
	OLED_12864::command(0xB8);
	OLED_12864::data(gs1 % 0xB5);
	OLED_12864::data(gs3 % 0xB5);
	OLED_12864::data(gs3 % 0xB5);
	OLED_12864::data(gs4 % 0xB5);
	OLED_12864::data(gs5 % 0xB5);
	OLED_12864::data(gs6 % 0xB5);
	OLED_12864::data(gs7 % 0xB5);
	OLED_12864::data(gs8 % 0xB5);
	OLED_12864::data(gs9 % 0xB5);
	OLED_12864::data(gs10 % 0xB5);
	OLED_12864::data(gs11 % 0xB5);
	OLED_12864::data(gs12 % 0xB5);
	OLED_12864::data(gs13 % 0xB5);
	OLED_12864::data(gs14 % 0xB5);
	OLED_12864::data(gs15 % 0xB5);
}

void OLED_12864::SetGrayscaleTblDefault(void) {
	OLED_12864::command(0xB9);
}

void OLED_12864::SetPrecharge(uint8_t vcc_mult) {
	OLED_12864::command(0xBB);
	OLED_12864::data(vcc_mult % 0x3F);
}

void OLED_12864::SetVCOMH(uint8_t vcomh_mult) {
	OLED_12864::command(0xBE);
	OLED_12864::data(vcomh_mult % 0x7);
}

void OLED_12864::SetContrast(uint8_t contrast) {
	OLED_12864::command(0xC1);
	OLED_12864::data(contrast);
}

void OLED_12864::MasterContrast(uint8_t contrast_red) {
	OLED_12864::command(0xC7);
	OLED_12864::data(contrast_red & 0xF);
}

void OLED_12864::SetMUXRatio(uint8_t ratio) {
	if(ratio < 15) {
		ratio = 15;
	}

	OLED_12864::command(0xCA);
	OLED_12864::data(ratio & 0x7F);
}

void OLED_12864::SetCmdLock(bool lock) {
	uint8_t a = 0x12;

	a |= (uint8_t)lock << 2;

	OLED_12864::command(0xFD);
	OLED_12864::data(a);
}

void OLED_12864::Init(void){
	OLED_12864::SetSleep(true);
	OLED_12864::SetClk_OscFreq(9, 1);
	OLED_12864::SetMUXRatio(0x3F);
	OLED_12864::SetDispOffset(0);
	OLED_12864::SetVDD(true);
	OLED_12864::SetRemap(false, true, true, true, false, true);
	OLED_12864::MasterContrast(0xF);
	OLED_12864::SetContrast(0x9F);
	OLED_12864::SetPhase(0xF, 0x2);
	OLED_12864::SetPrecharge(0x1F);
	OLED_12864::VSL_DispEnhance(false, true);
	OLED_12864::SetVCOMH(0x4);
	OLED_12864::DispMode(true, false);
	OLED_12864::SetSleep(false);
	HAL_Delay(10);
}



