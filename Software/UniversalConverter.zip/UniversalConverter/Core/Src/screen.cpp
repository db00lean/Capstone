/*
 * screen.cpp
 *
 *  Created on: Nov 24, 2021
 *      Author: davidboullie
 */

#include "screen.h"

void Screen::Init(void) {
	OLED.Init();
	font = Font();
	Clear();
}

void Screen::Clear(void) {
	unsigned int i, j;

	OLED.SetColAddr(0x1C, 0x5B);
	OLED.SetRowAddr(0x00, 0x3F);
	OLED.SetWriteRAM();

	for(i = 0; i < 64; i++) {
		for (j = 0; j < 128; j++){
			OLED.data(0x00);
		}
	}
}

void Screen::StartScreen(void) {
	char start_msg[] = "CAPSTONE TEAM B2";
	DrawText(25, 29, (char *)start_msg, false, 200);
	HAL_Delay(1500);
	DrawText(25, 29, (char *)start_msg, true);
	HAL_Delay(500);
	Clear();
}

void Screen::Checkerboard(void) {
	unsigned int i, j;

	OLED.SetColAddr(0x1C, 0x5B);
	OLED.SetRowAddr(0x00, 0x3F);
	OLED.SetWriteRAM();

	for(i = 0; i < 32; i++) {
		for (j = 0; j < 64; j++){
			OLED.data(0xFF);
			OLED.data(0x00);
		}
		for (j = 0; j < 64; j++){
			OLED.data(0x00);
			OLED.data(0xFF);
		}
	}
}

void Screen::DrawImage(uint8_t * image) {

	OLED.SetColAddr(0x1C, 0x5B);
	OLED.SetRowAddr(0x00, 0x3F);
	OLED.SetWriteRAM();

	for(int i = 0; i < 8192; i++) {
		OLED.data(image[i]);
	}
}

void Screen::DrawLetterArray(uint8_t start_x, uint8_t start_y, uint8_t array[7][6], bool highlight, bool first, uint8_t last_len) {

	uint8_t letter_x = start_x;
	uint8_t letter_len = 5;
	uint8_t pad_f = 0;
	uint8_t pad_b = 0;
	bool null_f, null_b;

	if(last_len) letter_len = last_len + 1;

	if(first && start_x){
		start_x -= 1;
		pad_f += 1;
	}

	if(start_x % 2) {
		start_x -= 1;
		pad_f += 1;
	}

	null_f = letter_x == start_x + 2;
	uint8_t end_x = start_x + letter_len + pad_f;

	if(end_x % 2) {
		end_x += 1;
		pad_b += 1;
		null_b = (bool)last_len;
	}

	uint8_t start_col = (start_x / 2) + SCREEN_COL_MIN;
	uint8_t start_row = start_y + SCREEN_ROW_MIN;

	uint8_t end_col = start_col + (((end_x - start_x) / 2) - 1);
	uint8_t end_row = start_row + 6;

	OLED.SetColAddr(start_col, end_col);
	OLED.SetRowAddr(start_row, end_row);
	OLED.SetWriteRAM();

	for(int y = 0; y < 7; y++) {
		for(int i = 0; i < pad_f; i++) {
			if(i == 0 && null_f) OLED.data(0x00);
			else SendHighlight(highlight);
		}
		for(int x = 0; x < letter_len; x++) {
			if (array[y][x]) SendHighlight(!highlight);
			else SendHighlight(highlight);
		}
		for(int i = 0; i < pad_b; i++) {
			if(null_b) OLED.data(0x00);
			else SendHighlight(highlight);
		}
	}
}

void Screen::SendHighlight(bool highlight) {
	if(highlight) OLED.data(0xFF);
	else OLED.data(0x00);
}

void Screen::DrawText(uint8_t start_x, uint8_t start_y, char * text, bool highlight, uint16_t delay) {
	int word_len = strlen(text);

	int x_offset = start_x;
	int y_offset = start_y;

	uint8_t last_len = 0;

	for(int i = 0; i < word_len; i++) {
		char letter = text[i];
		uint8_t letter_len = font.getLetterWidth(letter);

		if(x_offset + letter_len >= SCREEN_LENGTH) {
			y_offset += 7;
			x_offset = start_x;
		}

		if(y_offset >= SCREEN_HEIGHT - 5) {
			break;
		}

		if(i == word_len - 1) {
			last_len = letter_len;
		}

		if(letter == 'A' || letter == 'a') {
			DrawLetterArray(x_offset, y_offset, font.A, highlight, i == 0, last_len);
		} else if(letter == 'B' || letter == 'b') {
			DrawLetterArray(x_offset, y_offset, font.B, highlight, i == 0, last_len);
		} else if(letter == 'C' || letter == 'c') {
			DrawLetterArray(x_offset, y_offset, font.C, highlight, i == 0, last_len);
		} else if(letter == 'D' || letter == 'd') {
			DrawLetterArray(x_offset, y_offset, font.D, highlight, i == 0, last_len);
		} else if(letter == 'E' || letter == 'e') {
			DrawLetterArray(x_offset, y_offset, font.E, highlight, i == 0, last_len);
		} else if(letter == 'F' || letter == 'f') {
			DrawLetterArray(x_offset, y_offset, font.F, highlight, i == 0, last_len);
		} else if(letter == 'G' || letter == 'g') {
			DrawLetterArray(x_offset, y_offset, font.G, highlight, i == 0, last_len);
		} else if(letter == 'H' || letter == 'h') {
			DrawLetterArray(x_offset, y_offset, font.H, highlight, i == 0, last_len);
		} else if(letter == 'I' || letter == 'i') {
			DrawLetterArray(x_offset, y_offset, font.I, highlight, i == 0, last_len);
		} else if(letter == 'J' || letter == 'j') {
			DrawLetterArray(x_offset, y_offset, font.J, highlight, i == 0, last_len);
		} else if(letter == 'K' || letter == 'k') {
			DrawLetterArray(x_offset, y_offset, font.K, highlight, i == 0, last_len);
		} else if(letter == 'L' || letter == 'l') {
			DrawLetterArray(x_offset, y_offset, font.L, highlight, i == 0, last_len);
		} else if(letter == 'M' || letter == 'm') {
			DrawLetterArray(x_offset, y_offset, font.M, highlight, i == 0, last_len);
		} else if(letter == 'N' || letter == 'n') {
			DrawLetterArray(x_offset, y_offset, font.N, highlight, i == 0, last_len);
		} else if(letter == 'O' || letter == 'o') {
			DrawLetterArray(x_offset, y_offset, font.O, highlight, i == 0, last_len);
		} else if(letter == 'P' || letter == 'p') {
			DrawLetterArray(x_offset, y_offset, font.P, highlight, i == 0, last_len);
		} else if(letter == 'Q' || letter == 'q') {
			DrawLetterArray(x_offset, y_offset, font.Q, highlight, i == 0, last_len);
		} else if(letter == 'R' || letter == 'r') {
			DrawLetterArray(x_offset, y_offset, font.R, highlight, i == 0, last_len);
		} else if(letter == 'S' || letter == 's') {
			DrawLetterArray(x_offset, y_offset, font.S, highlight, i == 0, last_len);
		} else if(letter == 'T' || letter == 't') {
			DrawLetterArray(x_offset, y_offset, font.T, highlight, i == 0, last_len);
		} else if(letter == 'U' || letter == 'u') {
			DrawLetterArray(x_offset, y_offset, font.U, highlight, i == 0, last_len);
		} else if(letter == 'V' || letter == 'v') {
			DrawLetterArray(x_offset, y_offset, font.V, highlight, i == 0, last_len);
		} else if(letter == 'W' || letter == 'w') {
			DrawLetterArray(x_offset, y_offset, font.W, highlight, i == 0, last_len);
		} else if(letter == 'X' || letter == 'x') {
			DrawLetterArray(x_offset, y_offset, font.X, highlight, i == 0, last_len);
		} else if(letter == 'Y' || letter == 'y') {
			DrawLetterArray(x_offset, y_offset, font.Y, highlight, i == 0, last_len);
		} else if(letter == 'Z' || letter == 'z') {
			DrawLetterArray(x_offset, y_offset, font.Z, highlight, i == 0, last_len);
		} else if(letter == '1') {
			DrawLetterArray(x_offset, y_offset, font._1, highlight, i == 0, last_len);
		} else if(letter == '2') {
			DrawLetterArray(x_offset, y_offset, font._2, highlight, i == 0, last_len);
		} else if(letter == '3') {
			DrawLetterArray(x_offset, y_offset, font._3, highlight, i == 0, last_len);
		} else if(letter == '4') {
			DrawLetterArray(x_offset, y_offset, font._4, highlight, i == 0, last_len);
		} else if(letter == '5') {
			DrawLetterArray(x_offset, y_offset, font._5, highlight, i == 0, last_len);
		} else if(letter == '6') {
			DrawLetterArray(x_offset, y_offset, font._6, highlight, i == 0, last_len);
		} else if(letter == '7') {
			DrawLetterArray(x_offset, y_offset, font._7, highlight, i == 0, last_len);
		} else if(letter == '8') {
			DrawLetterArray(x_offset, y_offset, font._8, highlight, i == 0, last_len);
		} else if(letter == '9') {
			DrawLetterArray(x_offset, y_offset, font._9, highlight, i == 0, last_len);
		} else if(letter == '0') {
			DrawLetterArray(x_offset, y_offset, font._0, highlight, i == 0, last_len);
		} else if(letter == '.') {
			DrawLetterArray(x_offset, y_offset, font._punct, highlight, i == 0, last_len);
		} else if(letter == '!') {
			DrawLetterArray(x_offset, y_offset, font._excl, highlight, i == 0, last_len);
		} else if(letter == '?') {
			DrawLetterArray(x_offset, y_offset, font._quest, highlight, i == 0, last_len);
		} else if(letter == '-') {
			DrawLetterArray(x_offset, y_offset, font._hyph, highlight, i == 0, last_len);
		} else if(letter == ',') {
			DrawLetterArray(x_offset, y_offset, font._comma, highlight, i == 0, last_len);
		} else if(letter == '/') {
			DrawLetterArray(x_offset, y_offset, font._slash, highlight, i == 0, last_len);
		} else if(letter == '%') {
			DrawLetterArray(x_offset, y_offset, font._perc, highlight, i == 0, last_len);
		} else if(letter == '\'') {
			DrawLetterArray(x_offset, y_offset, font._apos, highlight, i == 0, last_len);
		} else if(letter == ':') {
			DrawLetterArray(x_offset, y_offset, font._colon, highlight, i == 0, last_len);
		} else if(letter == ';') {
			DrawLetterArray(x_offset, y_offset, font._semi, highlight, i == 0, last_len);
		} else if(letter == '|') {
			DrawLetterArray(x_offset, y_offset, font._line, highlight, i == 0, last_len);
		} else if(letter == ' ') {
			DrawLetterArray(x_offset, y_offset, font._space, highlight, i == 0, last_len);
		} else if(letter == '_') {
			DrawLetterArray(x_offset, y_offset, font._under, highlight, i == 0, last_len);
		} else if(letter == '(') {
			DrawLetterArray(x_offset, y_offset, font._paran_l, highlight, i == 0, last_len);
		} else if(letter == ')') {
			DrawLetterArray(x_offset, y_offset, font._paran_r, highlight, i == 0, last_len);
		}

		x_offset += letter_len + 1;

		HAL_Delay(delay);
	}
}

void Screen::DrawOption(Option o) {
	DrawText(o.x_coord, o.y_coord, o.text, o.highlight);
}

void Screen::Draw12x12(uint8_t start_x, uint8_t start_y, uint8_t array[12][12]) {
	uint8_t pad_f = 0;
	uint8_t pad_b = 0;

	if(start_x % 2) {
		start_x -= 1;
		pad_f += 1;
		pad_b += 1;
	}

	uint8_t end_x = start_x + 12 + pad_f + pad_b;

	uint8_t start_col = (start_x / 2) + SCREEN_COL_MIN;
	uint8_t start_row = start_y + SCREEN_ROW_MIN;

	uint8_t end_col = start_col + (((end_x - start_x) / 2) - 1);
	uint8_t end_row = start_row + 11;

	OLED.SetColAddr(start_col, end_col);
	OLED.SetRowAddr(start_row, end_row);
	OLED.SetWriteRAM();

	for(int y = 0; y < 12; y++) {
		if(pad_f) OLED.data(0x00);
		for(int x = 0; x < 12; x++) {
			if (array[y][x]) OLED.data(0xFF);
			else OLED.data(0x00);
		}
		if(pad_b) OLED.data(0x00);
	}
}

char * InttoString(uint16_t i) {
	char * ret;
	std::string val;
	val = std::to_string(i);
	ret = &val[0];
	return ret;
}

void Screen::DrawNumber(uint8_t dot_x, uint8_t start_y, uint16_t val, char unit, bool highlight) {
	char * c = InttoString(val);
	uint8_t str_len = strlen(c);
	uint8_t start_x = dot_x - (4 * (std::max((int)str_len, 4) - 2));

	char n[5];

	if(str_len < 4) {
		int i = 0;
		for(i = 0; i < 4 - str_len; i++) n[i] = '0';
		for(int j = 0; j < str_len; j++) n[j + i] = c[j];
	} else for(int i = 0; i < str_len; i++) n[i] = c[i];

	char m[9];
	char o[8];
	char * p;

	str_len = std::max((int)str_len, 4);

	for(int j = 0; j < str_len; j++) {
		if(j == str_len - 3) m[j] = '.';
		if(j >= str_len - 3) m[j+1] = n[j];
		else m[j] = n[j];
	}

	if(str_len > 4) {
		m[6] = ' ';
		m[7] = unit;
		m[8] = '\0';
		p = &m[0];
	} else {
		for(int i = 0; i < 5; i++) o[i] = m[i];
		o[5] = ' ';
		o[6] = unit;
		o[7] = '\0';
		start_x += 1;
		p = &o[0];
	}
	DrawText(start_x, start_y, p, highlight);
}

void Screen::DrawLine(uint8_t start_x, uint8_t start_y, bool horizontal, uint8_t length) {
	uint8_t pad_f = 0;
	uint8_t pad_b = 0;
	uint8_t end_x = 0;

	uint8_t x_length = 1;
	uint8_t y_length = 1;

	if(start_x % 2) {
		start_x -= 1;
		pad_f += 1;
	}

	if(horizontal) {
		end_x = start_x + pad_f + length;
		if(end_x % 2) pad_b += 1;
		x_length = length;
	} else {
		end_x = start_x + 2;
		if(!pad_f) pad_b += 1;
		y_length = length;
	}

	uint8_t start_col = (start_x / 2) + SCREEN_COL_MIN;
	uint8_t start_row = start_y + SCREEN_ROW_MIN;

	uint8_t end_col = start_col + (((end_x - start_x) / 2) - 1);
	uint8_t end_row = start_row + y_length - 1;

	OLED.SetColAddr(start_col, end_col);
	OLED.SetRowAddr(start_row, end_row);
	OLED.SetWriteRAM();

	for(int y = 0; y < y_length; y++) {
		if(pad_f) OLED.data(0x00);
		for(int x = 0; x < x_length; x++) OLED.data(0xFF);
		if(pad_b) OLED.data(0x00);
	}

}

void Screen::DrawLightning(uint8_t start_x, uint8_t start_y, bool on) {
	if(on) Draw12x12(start_x, start_y, font.LIGHTNING);
	else Draw12x12(start_x, start_y, font.EMPTY_LIGHTNING);
}

void Screen::DrawEmpty(uint8_t start_x, uint8_t start_y) {
	Draw12x12(start_x, start_y, font.EMPTY);
}

void Screen::MainSetup(void) {
	Clear();

	DrawText(17, 0, (char *)"UNIVERSAL CONVERTER", false);
	DrawLine(0, 7, true, 128);
	DrawLine(84, 8, false, 56);

	DrawText(9, 10, (char *)"V_IN 1", false);
	DrawText(51, 10, (char *)"V_IN 2", false);
	DrawText(94, 10, (char *)"V_OUT", false);

	DrawText(10, 30, (char *)"I_IN 1", false);
	DrawText(52, 30, (char *)"I_IN 2", false);
	DrawText(95, 30, (char *)"I_OUT", false);
}

void Screen::MainUpdate(uint16_t v_in_1, uint16_t i_in_1, bool state_1,
						uint16_t v_in_2, uint16_t i_in_2, bool state_2,
						uint16_t v_out, uint16_t i_out, bool out_state) {

	if(i_in_1 >= 10000) i_in_1 = 9999;
	if(i_in_2 >= 10000) i_in_2 = 9999;
	if(i_out >= 10000) i_out = 9999;

	DrawText(4, 18, (char *)"  ", false);
	DrawNumber(16, 18, v_in_1, 'V', false);
	DrawText(46, 18, (char *)"  ", false);
	DrawNumber(58, 18, v_in_2, 'V',  false);
	DrawText(89, 18, (char *)"  ", false);
	DrawNumber(101, 18, v_out, 'V', false);

	DrawText(2, 38, (char *)"  ", false);
	DrawNumber(12, 38, i_in_1, 'A', false);
	DrawText(44, 38, (char *)"  ", false);
	DrawNumber(55, 38, i_in_2, 'A', false);
	DrawText(88, 38, (char *)"  ", false);
	DrawNumber(98, 38, i_out, 'A', false);

	DrawLightning(16, 49, state_1);
	DrawLightning(59, 49, state_2);
	DrawLightning(102, 49, out_state);
}

void Screen::SettingsSetup(void) {
	DrawText(25, 0, (char *)"Output Settings");
	DrawLine(0, 7, true, 128);

	DrawText(25, 18, (char *)"V_out:");
	DrawText(95, 18, (char *)"V");
	DrawText(9, 36, (char *)"I_out max:");
}

void Screen::SettingsUpdate(uint16_t v_out, uint16_t i_out, uint8_t idx) {
	uint8_t start_x = 88;
	char * v_out_text = InttoString(v_out / 1000);

	if(v_out >= 10000) {
		start_x -= 5;
	}
	DrawText(83, 18, (char * )"  ");
	DrawText(start_x, 18, v_out_text, idx == 0);
	DrawNumber(83, 36, i_out, 'A', idx == 1);
	DrawText(54, 51, (char *)"Done", idx == 2);
}



