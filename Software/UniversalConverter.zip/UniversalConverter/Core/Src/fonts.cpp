/*
 * fonts.cpp
 *
 *  Created on: Nov 24, 2021
 *      Author: davidboullie
 */

#include "fonts.h"


uint8_t Font::getLetterWidth(char letter) {
	char one[] = " .'!,;:|";
	char two[] = "()";
	char three[] = "I-i";
	char five[] = "MTVWYmtvwy";
	if(strchr(one, letter) != NULL) {
		return 1;
	} else if(strchr(two, letter) != NULL) {
		return 2;
	} else if(strchr(three, letter) != NULL) {
		return 3;
	} else if(strchr(five, letter) != NULL) {
		return 5;
	} else {
		return 4;
	}
}


