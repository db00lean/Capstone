/*
 * screen.h
 *
 *  Created on: Nov 24, 2021
 *      Author: davidboullie
 */

#ifndef INC_SCREEN_H_
#define INC_SCREEN_H_

#include "OLED_12864.h"
#include "fonts.h"
#include "algorithm"

const uint8_t SCREEN_HEIGHT = 64;
const uint8_t SCREEN_LENGTH = 128;
const uint8_t SCREEN_COL_MIN = 28;
const uint8_t SCREEN_COL_MAX = 92;
const uint8_t SCREEN_ROW_MIN = 0;
const uint8_t SCREEN_ROW_MAX = SCREEN_HEIGHT;



class Option {
public:
	uint8_t idx;
	uint8_t x_coord;
	uint8_t y_coord;
	char * text;
	bool highlight;
	Option(uint8_t i, uint8_t x, uint8_t y, char * t) {
		idx = i;
		x_coord = x;
		y_coord = y;
		text = t;
		highlight = false;
	}
	void changeHighlight() {
		highlight = ! highlight;
	}
};

class Screen {
public:
	Font font;
	void Init(void);
	void Clear(void);
	void StartScreen(void);
	void Checkerboard(void);
	void DrawImage(uint8_t *);
	void DrawLetterArray(uint8_t, uint8_t, uint8_t[7][6], bool=false, bool=false, uint8_t=0);
	void SendHighlight(bool);
	void DrawText(uint8_t, uint8_t, char *, bool=false, uint16_t=0);
	void DrawOption(Option);
	void Draw12x12(uint8_t, uint8_t, uint8_t[12][12]);
	void DrawLine(uint8_t, uint8_t, bool, uint8_t);
	void DrawLightning(uint8_t, uint8_t, bool);
	void DrawEmpty(uint8_t, uint8_t);
	void MainSetup(void);
	void DrawNumber(uint8_t, uint8_t, uint16_t, char, bool);
	void MainUpdate(uint16_t, uint16_t, bool, uint16_t, uint16_t, bool, uint16_t, uint16_t, bool);
	void SettingsSetup(void);
	void SettingsUpdate(uint16_t, uint16_t, uint8_t);
private:
	OLED_12864 OLED;
};

#endif /* INC_SCREEN_H_ */
