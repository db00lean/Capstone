/*
 * controller.h
 *
 *  Created on: Dec 1, 2021
 *      Author: davidboullie
 */

#ifndef INC_CONTROLLER_H_
#define INC_CONTROLLER_H_

#include "screen.h"
extern ADC_HandleTypeDef hadc;


class Controller {
public:
	uint16_t v_out_sett_mV;
	uint16_t i_out_sett_mA;
	uint16_t v_in_1_read_mV;
	uint16_t i_in_1_read_mA;
	uint16_t v_in_2_read_mV;
	uint16_t i_in_2_read_mA;
	uint16_t v_out_read_mV;
	uint16_t i_out_read_mA;
	Screen screen;
	uint8_t ReadButton(uint8_t);
	bool ButtonPress(uint8_t);
	void ToggleLED(void);


	void start(void);

	void startSettings(void);
	void runSettings(void);

	void startMain(void);
	void runMain(void);

	void fetchReadings(void);

};

#endif /* INC_CONTROLLER_H_ */
