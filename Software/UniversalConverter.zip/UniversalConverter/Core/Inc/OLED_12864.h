/*
 * OLED_12864.h
 *
 *  Created on: Nov 24, 2021
 *      Author: davidboullie
 */

#ifndef INC_OLED_12864_H_
#define INC_OLED_12864_H_

#include "stm32l1xx_hal.h"
extern SPI_HandleTypeDef hspi1;

class OLED_12864 {
public:
	void command(uint8_t);
	void data(uint8_t);
	void EnableGrayscaleTbl(void);
	void SetColAddr(uint8_t, uint8_t);
	void SetRowAddr(uint8_t, uint8_t);
	void SetWriteRAM(void);
	void SetReadRAM(void);
	void SetRemap(bool, bool, bool, bool, bool, bool);
	void SetDispStart(uint8_t);
	void SetDispOffset(uint8_t);
	void DispMode(bool, bool);
	void PartialDisp(bool, uint8_t, uint8_t);
	void SetVDD(bool);
	void SetSleep(bool);
	void SetPhase(uint8_t, uint8_t);
	void SetClk_OscFreq(uint8_t, uint8_t);
	void VSL_DispEnhance(bool, bool);
	void SetGPIO(bool, bool, bool, bool);
	void Set2ndPrecharge(uint8_t);
	void SetGrayscaleTbl(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t,
			uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void SetGrayscaleTblDefault(void);
	void SetPrecharge(uint8_t);
	void SetVCOMH(uint8_t);
	void SetContrast(uint8_t);
	void MasterContrast(uint8_t);
	void SetMUXRatio(uint8_t);
	void SetCmdLock(bool);
	void Init(void);
};



#endif /* INC_OLED_12864_H_ */
