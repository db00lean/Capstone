/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"
#include "image.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define SRAM_BANK_ADDR ((uint32_t)0x64000000)
#define BUFFER_SIZE         ((uint32_t)0x0100) // = 256
#define WRITE_READ_ADDR     ((uint32_t)0x0800)

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
LTDC_HandleTypeDef hltdc;
FMC_NORSRAM_TimingTypeDef Timing;
SRAM_HandleTypeDef hsram1;

/* USER CODE BEGIN PV */
uint32_t aTxBuffer[BUFFER_SIZE];
uint32_t aRxBuffer[BUFFER_SIZE];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_FMC_Init(void);
static void MX_LTDC_Init(void);
static void Fill_Buffer(uint32_t *pBuffer, uint32_t uwBufferLenght, uint32_t uwOffset);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

char line_buffer[80];
uint8_t line_len;
uint8_t data_received_flag;

uint32_t uwIndex = 0;


int buf_size = 1;

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	  line_len = 1;
	  line_buffer[0] = '\r';

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FMC_Init();
  MX_USB_DEVICE_Init();
  MX_LTDC_Init();
  /* USER CODE BEGIN 2 */


  HAL_Delay(1000);

  uint8_t newline[] = "\n\r";

  uint8_t ping[] = "ping!\n\r";
  uint8_t welcome[] = "*** DigiMeter Serial Terminal***\n\rCreated By: Nick Hulsey\n\r";

  aRxBuffer[0] = 0x62656566;//0x64616564;//
  uint8_t recv_char[4] = {0};
  HAL_Delay(100);

  CDC_Transmit_FS(welcome,strlen(welcome));
  HAL_Delay(100);
  //CDC_Transmit_FS(recv_char,4);
  HAL_Delay(100);
  CDC_Transmit_FS(ping,strlen(ping));

  HAL_Delay(100);
  CDC_Transmit_FS(newline,strlen(newline));

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1){

	    /* USER CODE END WHILE */
		//CDC_Transmit_FS(Text,8); /*when commented the port is recognized*/
		//HAL_Delay(200);
		//Text[5]= data_received_flag + '0';
		HAL_Delay(10);

		if(data_received_flag == 1){
		  data_received_flag = 0;


		  //CDC_Transmit_FS(line_buffer,strlen(line_buffer));
		  HAL_Delay(100);
		  CDC_Transmit_FS(ping,strlen(ping));
		  HAL_Delay(5);
		  CDC_Transmit_FS(newline,2);

		  /*##-2- SRAM memory read/write access ######################################*/
		  /* Fill the buffer to write */
		  //Fill_Buffer(aTxBuffer, BUFFER_SIZE, 0x62656566);

		  for(int i=0; i< BUFFER_SIZE; i +=2){
			  aTxBuffer[i] = 0x62656566;
			  aTxBuffer[i+1] = 0x64656164;
		  }


		 int c = 1;
		 uint32_t tx_data;
		  for(int i = 1; i < 40; i +=4){
			 tx_data = (line_buffer[i+3] 		|
					 	 	 line_buffer[i+2] << 8  |
							 line_buffer[i+1] <<16  |
							 line_buffer[i] <<24) & 0xFFFFFFFF;
			 aTxBuffer[c] =  tx_data;
			 c++;
		  }

		  //Write data to the SRAM memory
		  for(uwIndex = 0; uwIndex < BUFFER_SIZE; uwIndex++)
		  {
		    *(__IO uint32_t *)(SRAM_BANK_ADDR + WRITE_READ_ADDR +4 * uwIndex) = aTxBuffer[uwIndex];
		  }

		  HAL_Delay(10);
		  /* Read back data from the SRAM memory */
		  for(uwIndex = 0; uwIndex < BUFFER_SIZE; uwIndex++)
		  {
		    aRxBuffer[uwIndex] = *(__IO uint32_t *)(SRAM_BANK_ADDR + WRITE_READ_ADDR +1+4 * uwIndex);
		  }

		  HAL_Delay(10);
		  //recv_char = {aRxBuffer[0] & 0xFF,(aRxBuffer[0] & 0xFF00)>>8 ,(aRxBuffer[0] & 0xFF0000)>>16,(aRxBuffer[0] & 0xFF000000)>>24 };

		  for(int i = 0; i < 20; i ++){
			  recv_char[3] = aRxBuffer[i] & 0xFF;
			  recv_char[2] = (aRxBuffer[i] & 0xFF00)>>8 ;
			  recv_char[1] = (aRxBuffer[i] & 0xFF0000) >>16;
			  recv_char[0] = (aRxBuffer[i] & 0xFF000000)>>24;
			  HAL_Delay(10);
		  	  CDC_Transmit_FS(recv_char,4);
			  HAL_Delay(10);
			  CDC_Transmit_FS(newline,2);
		  }


		  for(int i = 1; i < line_len;i++){
			line_buffer[i] = '\0';
			line_buffer[0] = '\r';
		  	  line_len = 1;
		  }
	    /* USER CODE BEGIN 3 */
	    }
	  }
	  /* USER CODE END 3 */
	}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};
  HAL_StatusTypeDef ret = HAL_OK;

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 360;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  RCC_OscInitStruct.PLL.PLLR = 6;

  ret = HAL_RCC_OscConfig(&RCC_OscInitStruct);
  if(ret != HAL_OK)
  {
    while(1) { ; }
  }

  /* Activate the OverDrive to reach the 180 MHz Frequency */
  ret = HAL_PWREx_EnableOverDrive();
  if(ret != HAL_OK)
  {
    while(1) { ; }
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  ret = HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
  if(ret != HAL_OK)
  {
    while(1) { ; }
  }

  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_LTDC;
  PeriphClkInitStruct.PLLSAI.PLLSAIN = 234;
  PeriphClkInitStruct.PLLSAI.PLLSAIR = 2;
  PeriphClkInitStruct.PLLSAIDivR = RCC_PLLSAIDIVR_4;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief LTDC Initialization Function
  * @param None
  * @retval None
  */
static void MX_LTDC_Init(void)
{

	  /* USER CODE BEGIN LTDC_Init 0 */

	  /* USER CODE END LTDC_Init 0 */

	  LTDC_LayerCfgTypeDef pLayerCfg = {0};
	  LTDC_LayerCfgTypeDef pLayerCfg1 = {0};

	  /* USER CODE BEGIN LTDC_Init 1 */

	  /* USER CODE END LTDC_Init 1 */
	  hltdc.Instance = LTDC;
	  hltdc.Init.HSPolarity = LTDC_HSPOLARITY_AL;
	  hltdc.Init.VSPolarity = LTDC_VSPOLARITY_AL;
	  hltdc.Init.DEPolarity = LTDC_DEPOLARITY_AL;
	  hltdc.Init.PCPolarity = LTDC_PCPOLARITY_IPC;
	  hltdc.Init.HorizontalSync = 47;
	  hltdc.Init.VerticalSync = 0;
	  hltdc.Init.AccumulatedHBP = 87;
	  hltdc.Init.AccumulatedVBP = 31;
	  hltdc.Init.AccumulatedActiveW = 887;
	  hltdc.Init.AccumulatedActiveH = 511;
	  hltdc.Init.TotalWidth = 927;
	  hltdc.Init.TotalHeigh = 524;
	  hltdc.Init.Backcolor.Blue = 50;
	  hltdc.Init.Backcolor.Green = 120;
	  hltdc.Init.Backcolor.Red = 255;
	  if (HAL_LTDC_Init(&hltdc) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  pLayerCfg.WindowX0 = 0;
	  pLayerCfg.WindowX1 = 800;
	  pLayerCfg.WindowY0 = 0;
	  pLayerCfg.WindowY1 = 480;
	  pLayerCfg.PixelFormat = LTDC_PIXEL_FORMAT_RGB888;//LTDC_PIXEL_FORMAT_RGB565;
	  pLayerCfg.Alpha = 255;
	  pLayerCfg.Alpha0 = 0;
	  pLayerCfg.BlendingFactor1 = LTDC_BLENDING_FACTOR1_PAxCA;
	  pLayerCfg.BlendingFactor2 = LTDC_BLENDING_FACTOR1_PAxCA;

	  pLayerCfg.FBStartAdress = (uint32_t) &image_data_Untitled;
	  pLayerCfg.ImageWidth = 800;
	  pLayerCfg.ImageHeight = 480;

	  pLayerCfg.Backcolor.Blue = 0;
	  pLayerCfg.Backcolor.Green = 0;
	  pLayerCfg.Backcolor.Red = 0;
	  if (HAL_LTDC_ConfigLayer(&hltdc, &pLayerCfg, 0) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  pLayerCfg1.WindowX0 = 0;
	  pLayerCfg1.WindowX1 = 0;
	  pLayerCfg1.WindowY0 = 0;
	  pLayerCfg1.WindowY1 = 0;
	  pLayerCfg1.PixelFormat = LTDC_PIXEL_FORMAT_ARGB8888;
	  pLayerCfg1.Alpha = 0;
	  pLayerCfg1.Alpha0 = 0;
	  pLayerCfg1.BlendingFactor1 = LTDC_BLENDING_FACTOR1_CA;
	  pLayerCfg1.BlendingFactor2 = LTDC_BLENDING_FACTOR2_CA;
	  pLayerCfg1.FBStartAdress = 0;
	  pLayerCfg1.ImageWidth = 0;
	  pLayerCfg1.ImageHeight = 0;
	  pLayerCfg1.Backcolor.Blue = 0;
	  pLayerCfg1.Backcolor.Green = 0;
	  pLayerCfg1.Backcolor.Red = 0;
	  if (HAL_LTDC_ConfigLayer(&hltdc, &pLayerCfg1, 1) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  /* USER CODE BEGIN LTDC_Init 2 */

	  /* USER CODE END LTDC_Init 2 */
}

/* FMC initialization function */
static void MX_FMC_Init(void)
{

	/*##-1- Configure the SRAM device ##########################################*/
	  /* SRAM device configuration */

	  hsram1.Instance  = FMC_NORSRAM_DEVICE;
	  hsram1.Extended  = FMC_NORSRAM_EXTENDED_DEVICE;

	  /* SRAM device configuration */
	  Timing.AddressSetupTime       = 2;
	  Timing.AddressHoldTime        = 2;
	  Timing.DataSetupTime          = 3;
	  Timing.BusTurnAroundDuration  = 2;
	  Timing.CLKDivision            = 3;
	  Timing.DataLatency            = 2;
	  Timing.AccessMode             = FMC_ACCESS_MODE_A;

	  hsram1.Init.NSBank             = FMC_NORSRAM_BANK2;
	  hsram1.Init.DataAddressMux     = FMC_DATA_ADDRESS_MUX_DISABLE;
	  hsram1.Init.MemoryType         = FMC_MEMORY_TYPE_SRAM;
	  hsram1.Init.MemoryDataWidth    = FMC_NORSRAM_MEM_BUS_WIDTH_8;
	  hsram1.Init.BurstAccessMode    = FMC_BURST_ACCESS_MODE_DISABLE;
	  hsram1.Init.WaitSignalPolarity = FMC_WAIT_SIGNAL_POLARITY_LOW;
	  hsram1.Init.WrapMode           = FMC_WRAP_MODE_DISABLE;
	  hsram1.Init.WaitSignalActive   = FMC_WAIT_TIMING_BEFORE_WS;
	  hsram1.Init.WriteOperation     = FMC_WRITE_OPERATION_ENABLE;
	  hsram1.Init.WaitSignal         = FMC_WAIT_SIGNAL_DISABLE;
	  hsram1.Init.ExtendedMode       = FMC_EXTENDED_MODE_DISABLE;
	  hsram1.Init.AsynchronousWait   = FMC_ASYNCHRONOUS_WAIT_DISABLE;
	  hsram1.Init.WriteBurst         = FMC_WRITE_BURST_DISABLE;

	  HAL_SRAM_DeInit(&hsram1);
	  /* Initialize the SRAM controller */
	  if(HAL_SRAM_Init(&hsram1, &Timing, &Timing) != HAL_OK)
	  {
	    /* Initialization Error */
	    Error_Handler();
	  }

	  /*##-2- SRAM memory read/write access ######################################*/
	  /* Fill the buffer to write */
	  Fill_Buffer(aTxBuffer, BUFFER_SIZE, 0xC20FC210);

	  /* Write data to the SRAM memory */
	  for(uwIndex = 0; uwIndex < BUFFER_SIZE; uwIndex++)
	  {
	    *(__IO uint32_t *)(SRAM_BANK_ADDR + WRITE_READ_ADDR + 4 * uwIndex) = aTxBuffer[uwIndex];
	  }

	  /* Read back data from the SRAM memory */
	  for(uwIndex = 0; uwIndex < BUFFER_SIZE; uwIndex++)
	  {
	    aRxBuffer[uwIndex] = *(__IO uint32_t *)(SRAM_BANK_ADDR + WRITE_READ_ADDR + 4 * uwIndex);
	  }
}
/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOI_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOJ_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOK_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_SET);

  /*Configure GPIO pin : PB10 */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
static void Fill_Buffer(uint32_t *pBuffer, uint32_t uwBufferLength, uint32_t uwOffset)
{
  uint32_t tmpIndex = 0;

  /* Put in global buffer different values */
  for (tmpIndex = 0; tmpIndex < uwBufferLength; tmpIndex++)
  {
    pBuffer[tmpIndex] =uwOffset;
  }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
